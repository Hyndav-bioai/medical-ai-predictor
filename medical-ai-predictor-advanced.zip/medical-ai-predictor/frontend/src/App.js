import React from "react";

function App() {
  return (
    <div style={{ padding: "40px" }}>
      <h1>Medical AI Disease Predictor</h1>
      <p>AI-powered healthcare prediction system.</p>
    </div>
  );
}

export default App;
