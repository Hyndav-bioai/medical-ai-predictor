from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np

app = Flask(__name__)
CORS(app)

model = pickle.load(open("model.pkl", "rb"))

symptoms_list = [
    "fever",
    "cough",
    "headache",
    "fatigue",
    "body_pain"
]

@app.route("/")
def home():
    return jsonify({"message": "Medical AI API Running"})

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    symptoms = data.get("symptoms", [])

    input_data = []

    for symptom in symptoms_list:
        input_data.append(1 if symptom in symptoms else 0)

    input_array = np.array(input_data).reshape(1, -1)

    prediction = model.predict(input_array)
    probabilities = model.predict_proba(input_array)

    confidence = round(np.max(probabilities) * 100, 2)

    return jsonify({
        "prediction": prediction[0],
        "confidence": confidence
    })

if __name__ == "__main__":
    app.run(debug=True)
