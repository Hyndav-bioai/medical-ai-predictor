responses = {
    "fever": "Stay hydrated and monitor your temperature.",
    "cough": "Warm fluids may help your throat."
}

def medical_chatbot(message):
    message = message.lower()

    for key in responses:
        if key in message:
            return responses[key]

    return "Please consult a healthcare professional."
