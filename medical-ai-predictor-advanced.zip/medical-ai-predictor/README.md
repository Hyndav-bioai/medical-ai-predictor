# Medical AI Disease Predictor

AI-powered healthcare disease prediction system using Machine Learning, Flask, React, Random Forest, XGBoost, and Neural Networks.

## Features
- Disease prediction
- Confidence scores
- Medical chatbot
- Flask API
- React frontend

## Run Backend
```bash
cd backend
pip install -r requirements.txt
python train_model.py
python app.py
```

## Run Frontend
```bash
cd frontend
npm install
npm start
```
